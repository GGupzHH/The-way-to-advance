<template>
  <div>
    这是 Photo 页面
  </div>
</template>

<script>

export default {
  name: 'Photo'
}
</script>
